Pour lancer, il suffit d'installer wildfly en téléchargeant l'archive sur le site officiel et lancer le serveur web avec ./bin/standalone.sh.

Pour deployer le TP sur wildfly, il suffit d'installer maven et de faire mvn wildfly:deploy dans le répertoire du TP.

CORRIGÉS